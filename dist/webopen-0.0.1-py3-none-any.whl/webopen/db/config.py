import os

DATABASE_URL = "./credentials.db"